public class Circle implements Shape{
    int radius=0;

    public Circle(int radius){
        this.radius=radius;
    }
    public double calculateArea(){
        return (double)(radius*radius*Math.PI);
    }
    public void display(){
        System.out.println(calculateArea());
    }
}