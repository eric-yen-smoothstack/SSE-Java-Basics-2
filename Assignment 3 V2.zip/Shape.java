public interface Shape{
    public double calculateArea();
    public void display();
}