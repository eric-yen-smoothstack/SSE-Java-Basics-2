public class Triangle implements Shape{
    int length=0;
    int height=0;
    public Triangle(int length,int height){
        this.length=length;
        this.height=height;
    }
    public double calculateArea(){
        return (double)(length*height/2);
    }
    public void display(){
        System.out.println("I'm a triangle!");
    }
}