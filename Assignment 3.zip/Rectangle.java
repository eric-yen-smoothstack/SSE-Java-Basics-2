public class Rectangle implements Shape{
    int length=0;
    int height=0;
    public Rectangle(int length,int height){
        this.length=length;
        this.height=height;
    }
    public double calculateArea(){
        return (double)(length*height);
    }
    public void display(){
        System.out.println("I'm a rectangle!");
    }
}